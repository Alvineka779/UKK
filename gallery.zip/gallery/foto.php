<?php
include "koneksi.php";
session_start();
if (!isset($_SESSION['UserID'])) {
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Foto - Gallery</title>
</head>
<body>       
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="Home.php">Profile</a></li>
        <li><a href="album.php">Album</a></li>
        <li><a href="foto.php">Foto</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
    <h1>Halaman Foto</h1>
    <marquee>Hi, <?=$_SESSION['NamaLengkap']?></marquee>
    <form action="tambah-foto.php" method="post" enctype="multipart/form-data">
        <table>
        <tr>
            <td>Judul Foto</td>
            <td><input type="text" name="JudulFoto" id="JudulFoto" placeholder="Masukan Judul Foto" required></td>
        </tr>
        <tr>
            <td>Deskripsi Foto</td>
            <td><input type="text" name="DeskripsiFoto" id="DeskripsiFoto" placeholder="Masukan Deskripsi Foto" required></td>
        </tr>
        <tr>
            <td>Foto</td>
            <td><input type="file" name="LokasiFile" id="LokasiFile"  required></td>
        </tr>
        <tr>
            <td>Album</td>
            <td>
                <select name="AlbumID">
                    <option>Pilih Album</option>
                    <?php
                    include "koneksi.php";
                    $sql = mysqli_query($koneksi, "SELECT * FROM album,user WHERE album.UserID=user.UserID")or die(mysqli_error($koneksi));
                    while ($data =  mysqli_fetch_array($sql)) {
                    ?>
                    <option value="<?=$data['AlbumID']?>"><?=$data['NamaAlbum']?></option>
                    <?php } ?>
                    
                </select>
            </td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" value="Simpan"></td>
        </tr>
        </table>
    </form>

    <table border="1" width="100%" cellpadding="5" cellspacing="0">
        <tr>
            <th>ID</th>
            <th>Judul Foto</th>
            <th>Deskripsi Foto</th>
            <th>Foto</th>
            <th>Album</th>
            <th>Aksi</th>
        </tr>
        <?php
        include "koneksi.php";
        $UserID = $_SESSION['UserID'];
        $sql = mysqli_query($koneksi, "SELECT * FROM foto,album WHERE foto.userid='$UserID' AND foto.AlbumId=album.AlbumID")or die(mysqli_error($koneksi));
        while ($data = mysqli_fetch_array($sql)) {
        ?>
            <tr align="center">
                <td><?=$data['FotoID']?></td>
                <td><?=$data['JudulFoto']?></td>
                <td><?=$data['DeskripsiFoto']?></td>
                <td>
                    <img src="gambar/<?=$data['LokasiFile']?>" width="200px">    
                </td>
                <td><?=$data['NamaAlbum']?></td>
                <td>
                    <a href="edit-foto.php?FotoID=<?=$data['FotoID']?>">Edit</a>
                    <a href="hapus-foto.php?FotoID=<?=$data['FotoID']?>">Hapus</a>
                </td>
            </tr>
        <?php } ?>
    </table>

</body>
</html>