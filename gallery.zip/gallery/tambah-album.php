<?php
include "koneksi.php";
session_start();

$NamaAlbum = $_POST['NamaAlbum'];
$Deskripsi = $_POST['Deskripsi'];
$TanggaDibuat = date("Y-m-d");
$UserID = $_SESSION['UserID'];

$sql = mysqli_query($koneksi, "INSERT INTO album VALUES('', '$NamaAlbum', '$Deskripsi', '$TanggaDibuat', '$UserID' )")or die(mysqli_error($koneksi));

header("location:album.php");

?>