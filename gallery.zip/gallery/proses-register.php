<?php
include "koneksi.php";

$Username = $_POST['Username'];
$Password = $_POST['Password'];
$Email = $_POST['Email'];
$NamaLengkap = $_POST['NamaLengkap'];
$Alamat = $_POST['Alamat'];

$sql = mysqli_query($koneksi, "INSERT INTO user VALUES('','$Username','$Password','$Email','$NamaLengkap','$Alamat')")or die(mysqli_error($koneksi));

header("location:login.php");

?>