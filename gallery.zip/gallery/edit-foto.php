<?php
include "koneksi.php";
session_start();
if (!isset($_SESSION['UserID'])) {
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Foto - Gallery</title>
</head>
<body>       
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="Home.php">Profile</a></li>
        <li><a href="album.php">Album</a></li>
        <li><a href="foto.php">Foto</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
    <h1>Halaman Foto</h1>
    <marquee>Hi, <?=$_SESSION['NamaLengkap']?></marquee>
    <form action="update-foto.php" method="post" enctype="multipart/form-data">
        <?php
        include "koneksi.php";
        $FotoID = $_GET['FotoID'];
        $sql = mysqli_query($koneksi, "SELECT * FROM foto WHERE FotoID='$FotoID'");
        while ($data = mysqli_fetch_array($sql)) {
        ?>
        <input type="text" name="FotoID" value="<?=$data['FotoID']?>" hidden>
        <table>
        <tr>
            <td>Judul Foto</td>
            <td><input type="text" name="JudulFoto" id="JudulFoto" value="<?=$data['JudulFoto']?>" required></td>
        </tr>
        <tr>
            <td>Deskripsi Foto</td>
            <td><input type="text" name="DeskripsiFoto" id="DeskripsiFoto" value="<?=$data['DeskripsiFoto']?>" required></td>
        </tr>
        <tr>
            <td>Foto Lama</td>
            <td><img src="gambar/<?=$data['LokasiFile']?>" width="200px">    </td>
        </tr>
        <tr>
            <td>Foto</td>
            <td><input type="file" name="LokasiFile" id="LokasiFile"  required></td>
        </tr>
        <tr>
            <td>Album</td>
            <td>
                <select name="AlbumID">
                    <option>Pilih Album</option>
                    <?php
                    include "koneksi.php";
                    $sql2 = mysqli_query($koneksi, "SELECT * FROM album,user WHERE album.UserID=user.UserID")or die(mysqli_error($koneksi));
                    while ($data2 =  mysqli_fetch_array($sql2)) {
                    ?>
                    <option value="<?=$data2['AlbumID']?>" <?php if($data2['AlbumID'] == $data2['AlbumID']) {echo "selected";} ?>><?=$data2['NamaAlbum']?></option>
                    <?php } ?>
                    
                </select>
            </td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" value="Ubah"></td>
        </tr>
        </table>
        <?php } ?>
    </form>

</body>
</html>