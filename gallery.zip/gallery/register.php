<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Register - Gallery</title>
</head>
<body>
    
<div class="container-regis">
    <h1 class="regis">Register - Gallery</h1>
    <form action="proses-register.php" method="post">
        <table class="tables">
            <tr>
                <td class="text">Nama Lengkap</td>
                <td><input type="text" class="box" name="NamaLengkap" id="NamaLengkap" placeholder="Masukan Nama Lengkap" required></td>
            </tr>
            <tr>
                <td class="text">Username</td>
                <td><input type="text" class="box" name="Username" id="Username" placeholder="Masukan Username" required></td>
            </tr>
            <tr>
                <td class="text">Password</td>
                <td><input type="password" class="box" name="Password" id="Password" placeholder="Masukan Password" required></td>
            </tr>
            <tr>
                <td class="text">Email</td>
                <td><input type="email" class="box" name="Email" id="Email" placeholder="Masukan Email" required></td>
            </tr>
            <tr>
                <td class="text">Alamat</td>
                <td><input type="text" class="box" name="Alamat" id="Alamat" placeholder="Masukan Alamat" required></td>
            </tr>
            <tr>
                <td></td>
                <td><br><input type="submit" class="button" value="Register"> <a class="link" href="login.php">Login</a></td>
            </tr>
        </table>
    </form>
</div>
</body>
</html>