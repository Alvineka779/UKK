<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Login - Gallery</title>
</head>
<body>
    <div class="container">
    <h1 class="login">Login - Gallery</h1>
    <form action="proses-login.php" method="post">
        <table class="tables">
            <tr>
                <td class="text">Username</td>
                <td><input class="box" type="text" name="Username" id="Username" placeholder="Masukan Username" required></td>
            </tr>
            <tr>
                <td class="text">Password</td>
                <td><input class="box" type="password" name="Password" id="Password" placeholder="Masukan Password" required></td>
            </tr>
            <tr class="aksi">
                <td></td>
                <td><br><input type="submit" class="button" value="Login"> <a class="link" href="register.php">Register</a></td>
            </tr>
        </table>
    </form>
    </div>

</body>
</html>