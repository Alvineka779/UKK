<?php
include "koneksi.php";
session_start();

$AlbumID = $_POST['AlbumID'];
$NamaAlbum = $_POST['NamaAlbum'];
$Deskripsi = $_POST['Deskripsi'];
$TanggalDibuat = date("Y-m-d");
$UserID = $_SESSION['UserID'];

$sql = mysqli_query($koneksi, "UPDATE album SET NamaAlbum='$NamaAlbum', Deskripsi='$Deskripsi', TanggalDibuat='$TanggalDibuat', UserID='$UserID' WHERE AlbumID='$AlbumID'")or die(mysqli_error($koneksi));

header("location:album.php");

?>