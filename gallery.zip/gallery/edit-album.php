<?php
include "koneksi.php";
session_start();
if (!isset($_SESSION['UserID'])) {
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Edit Album - Gallery</title>
</head>
<body>
    
        
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="Home.php">Profile</a></li>
        <li><a href="album.php">Album</a></li>
        <li><a href="foto.php">Foto</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
    <h1>Halaman Edit Album</h1>
    <marquee>Hi, <?=$_SESSION['NamaLengkap']?></marquee>
    <form action="update-album.php" method="post">
        <?php
        include "koneksi.php";
        $AlbumID = $_GET['AlbumID'];
        $sql = mysqli_query($koneksi, "SELECT * FROM album WHERE AlbumID='$AlbumID'")or die(mysqli_error($koneksi));
        while ($data = mysqli_fetch_array($sql)) {
        ?>
        <input type="text" name="AlbumID" value="<?=$data['AlbumID']?>" hidden>
            <table>
                <tr>
                    <td>Nama Album</td>
                    <td><input type="text" name="NamaAlbum" id="NamaAlbum" value="<?=$data['NamaAlbum']?>" required></td>
                </tr>
                <tr>
                    <td>Deskripsi Album</td>
                    <td><input type="text" name="Deskripsi" id="Deskripsi"value="<?=$data['Deskripsi']?>" required></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" value="Ubah"> <button><a href="album.php">Kembali</a></button></td>
                </tr>
        <?php } ?>
        </table>
    </form>
    <hr>
    <table border="1" width="100%" cellpadding="5" cellspacing="0">
        <tr>
            <th>ID</th>
            <th>Nama Album</th>
            <th>Deskripsi Album</th>
            <th>Tanggal Di Buat</th>
        </tr>
        <?php
        include "koneksi.php";
        $sql = mysqli_query($koneksi, "SELECT * FROM album,user WHERE album.UserID=user.UserID")or die(mysqli_error($koneksi));
        while($data = mysqli_fetch_array($sql)){
        ?>
            <tr>
                <td align="center"><?=$data['AlbumID']?></td>
                <td align="center"><?=$data['NamaAlbum']?></td>
                <td align="center"><?=$data['Deskripsi']?></td>
                <td align="center"><?=$data['TanggalDibuat']?></td>
            </tr>
        <?php } ?>
    </table>

</body>
</html>