<?php
include "koneksi.php";
session_start();

$JudulFoto = $_POST['JudulFoto'];
$DeskripsiFoto = $_POST['DeskripsiFoto'];
$TanggalUnggah = date("Y-m-d");
$AlbumID = $_POST['AlbumID'];
$UserID = $_SESSION['UserID'];

$rand = rand();
$extensi = array('png', 'jpg', 'jpeg', 'gif');
$filename = $_FILES['LokasiFile']['name'];
$ukuran = $_FILES['LokasiFile']['size'];
$ext = pathinfo($filename, PATHINFO_EXTENSION);

if (!in_array($ext, $extensi)) {
    header("location:foto.php");
}else{
    if ($ukuran < 31457280) {
        $xx = $rand.'_'.$filename;
        move_uploaded_file($_FILES['LokasiFile']['tmp_name'], 'gambar/'.$rand.'_'.$filename);
        $sql = mysqli_query($koneksi, "INSERT INTO foto VALUES('', '$JudulFoto', '$DeskripsiFoto', '$TanggalUnggah', '$xx', '$AlbumID', '$UserID')")or die(mysqli_error($koneksi));
        header("location:foto.php");
    }else{
        header("location:foto2.php");
    }
}