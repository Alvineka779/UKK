<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Halaman Utama</title>
</head>
<body>
    
    <?php
    include "koneksi.php";
    session_start();
    if (!isset($_SESSION['UserID'])) {
    ?>

    <ul>
        <li><a href="register.php">Register</a></li>
        <li><a href="login.php">Login</a></li>
    </ul>
    <br>
    <h1>Selamat Datang Di Website Gallery</h1>
    <br>
    <p>Anda Belum Login</p>
    <br>
    <?php }else{ ?>
    
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="Home.php">Profile</a></li>
        <li><a href="album.php">Album</a></li>
        <li><a href="foto.php">Foto</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
    <h1>Selamat Datang Di Website Gallery</h1>
    <marquee>Hi, <?=$_SESSION['NamaLengkap']?></marquee>
    <?php } ?>
    <table border="1" width="100%" cellpadding="5" cellspacing="0">
        <tr>
            <th>ID</th>
            <th>Judul Foto</th>
            <th>Deskripsi Foto</th>
            <th>Foto</th>
            <th>Uploder</th>
            <th>Jumlah Like</th>
            <th>Aksi</th>
        </tr>
        <?php
        include "koneksi.php";
        $sql = mysqli_query($koneksi, "SELECT * FROM foto,user WHERE foto.userid=user.userid")or die(mysqli_error($koneksi));
        while ($data = mysqli_fetch_array($sql)) {
        ?>
            <tr align="center">
                <td><?=$data['FotoID']?></td>
                <td><?=$data['JudulFoto']?></td>
                <td><?=$data['DeskripsiFoto']?></td>
                <td><img src="gambar/<?=$data['LokasiFile']?>" width="200px"></td>
                <td><?=$data['NamaLengkap']?></td>
                <td>
                    <?php
                    $FotoID = $data['FotoID'];
                    $sql2 = mysqli_query($koneksi, "SELECT * FROM likefoto WHERE FotoID='$FotoID' ")or die (mysqli_error($koneksi));
                    echo mysqli_num_rows($sql2);
                    ?>
                </td>
                <td>
                    <a href="like.php?FotoID=<?=$data['FotoID']?>">Like</a>
                    <a href="komentar.php?FotoID=<?-$data['FotoID']?>">Komentar</a>
                </td>
            </tr>
        <?php } ?>
    </table>

</body>
</html>